(function(window, undefined) {

  var jimLinks = {
    "cadcdbd5-d639-4865-b840-0c142b724760" : {
      "Image_1" : [
        "d0dd2625-f713-4551-b499-4d443c02ec61"
      ]
    },
    "d0dd2625-f713-4551-b499-4d443c02ec61" : {
      "Label_16" : [
        "cadcdbd5-d639-4865-b840-0c142b724760"
      ]
    },
    "3ffb8bac-90d8-41d3-9a2e-efff5bfe6f6d" : {
      "Background" : [
        "cadcdbd5-d639-4865-b840-0c142b724760"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);