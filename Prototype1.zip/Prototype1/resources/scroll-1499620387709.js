(function(window, undefined) {

    /*********************** START STATIC ACCESS METHODS ************************/

    jQuery.extend(jimMobile, {
        "loadScrollBars": function() {
            jQuery(".s-cadcdbd5-d639-4865-b840-0c142b724760 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-cadcdbd5-d639-4865-b840-0c142b724760 #s-Panel_2").overscroll({ showThumbs:false, direction:'vertical' });
            jQuery(".s-d0dd2625-f713-4551-b499-4d443c02ec61 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-3ffb8bac-90d8-41d3-9a2e-efff5bfe6f6d .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
         }
    });

    /*********************** END STATIC ACCESS METHODS ************************/

}) (window);